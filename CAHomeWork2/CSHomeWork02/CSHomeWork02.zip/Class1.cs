﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSHomeWork02
{
    public partial class TMyVent
    {
        public  void Print()
        {
            Console.WriteLine("Print from another File");
        }

    }
}
